# Diário de Classe — Android exclusivamente offline

Esta pasta contém o projeto-fonte para gerar um aplicativo Android com base no HTML fornecido.

## O que esta versão faz
- Funciona sem internet.
- Salva os dados localmente no aparelho.
- Mantém as funções da página original, incluindo turmas, alunos, chamada, atividades, resumo e backup/restauração.
- Não usa conta, Firebase, nuvem nem sincronização com computador/outros celulares.
- Remove a dependência de fontes externas para que a interface não precise da internet.

## Atenção aos dados
Os dados ficam no armazenamento do aplicativo nesse aparelho. Desinstalar o aplicativo, limpar os dados dele ou trocar de aparelho pode apagar os registros. Faça backups regularmente pelo menu **Backup**. Se o botão de baixar arquivo não funcionar em determinado aparelho, use **Copiar texto** e guarde o texto do backup em local seguro. Para restaurar, cole o texto no campo de restauração e toque em **Importar**.

## Como gerar o APK
É necessário um computador com Node.js LTS e Android Studio instalados. Este ZIP é o projeto-fonte; ele ainda não é um APK compilado.

1. Extraia o ZIP para uma pasta.
2. Abra um terminal nessa pasta.
3. Execute:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. No Android Studio, aguarde a sincronização do Gradle.
5. Para gerar um APK de teste, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Ao concluir, o Android Studio mostrará a localização do APK.

Se `npx cap add android` informar que a plataforma já existe, pule esse comando e execute `npx cap sync android`.

## Observação
O projeto foi preparado a partir do HTML recebido e configurado para armazenamento local. Antes de usar com registros reais de uma turma, teste criar turma/aluno, registrar chamada, fechar e abrir o app, exportar backup e restaurá-lo.
